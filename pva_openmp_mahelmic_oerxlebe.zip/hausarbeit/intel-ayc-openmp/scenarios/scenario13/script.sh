#!/bin/bash

../../run -nb_threads 2 -from C1 -to C100 -departure_time_min 00000000100000 -departure_time_max 00000000450000 -arrival_time_min 00000000550000 -arrival_time_max 00000000900000 -max_layover 1000 -vacation_time_min 50000 -vacation_time_max 200000 -flights flights.txt -alliances alliances.txt -work_hard_file work_hard.txt -play_hard_file play_hard.txt -vacation_airports c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12 c13 c14 c15 c16 c17 c18 c19 c20 c21 c22 c23 c24 c25 c26 c27 c28 c29 c30 c31 c32 c33 c34 c35 c36 c37 c38 c39 c40 c41 c42 c43 c44 c45 c46 c47 c48 c49 c50 c51
