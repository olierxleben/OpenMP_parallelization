var searchData=
[
  ['alliances',['Alliances',['../types_8h.html#a942cbcc40778424afe78605ae5c364c0',1,'types.h']]]
];
