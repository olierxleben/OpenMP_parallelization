var searchData=
[
  ['has_5fjust_5ftraveled_5fwith_5falliance',['has_just_traveled_with_alliance',['../main_8cpp.html#a92c6d4c19cb49fdabe4ae8de8e5c838b',1,'has_just_traveled_with_alliance(Flight *flight_before, Flight *current_flight, Alliances *alliances):&#160;main.cpp'],['../methods_8h.html#a92c6d4c19cb49fdabe4ae8de8e5c838b',1,'has_just_traveled_with_alliance(Flight *flight_before, Flight *current_flight, Alliances *alliances):&#160;main.cpp']]],
  ['has_5fjust_5ftraveled_5fwith_5fcompany',['has_just_traveled_with_company',['../main_8cpp.html#a8a9dea9cf1aec3c1bbb6533248d6c19b',1,'has_just_traveled_with_company(Flight *flight_before, Flight *current_flight):&#160;main.cpp'],['../methods_8h.html#a8a9dea9cf1aec3c1bbb6533248d6c19b',1,'has_just_traveled_with_company(Flight *flight_before, Flight *current_flight):&#160;main.cpp']]]
];
