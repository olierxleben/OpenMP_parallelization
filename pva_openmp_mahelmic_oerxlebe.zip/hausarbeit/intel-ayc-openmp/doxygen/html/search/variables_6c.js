var searchData=
[
  ['land_5ftime',['land_time',['../struct_flight.html#a8595c2a4dbdb6b5c4f391bd46aae2109',1,'Flight']]],
  ['location_5fmap',['location_map',['../main_8cpp.html#abf176f024441f44700ccbb2bb6a9cc35',1,'main.cpp']]]
];
