var searchData=
[
  ['work_5fhard',['work_hard',['../class_solution.html#aa01e223ab1abc7d44183834d542ecc6b',1,'Solution']]],
  ['work_5fhard_5ffile',['work_hard_file',['../struct_parameters.html#a5e8fd1fc0d362cde3e1e5094d3f8b253',1,'Parameters']]]
];
