var searchData=
[
  ['get_5fcheapest',['get_cheapest',['../classoma_1_1_path_merging_outer_loop.html#a4186ce8bbac37b759b77b8c457cd2fac',1,'oma::PathMergingOuterLoop::get_cheapest()'],['../classoma_1_1_path_merging_triple_outer_loop.html#a98c5fc77dd1080927d366d68b044cb47',1,'oma::PathMergingTripleOuterLoop::get_cheapest()']]]
];
