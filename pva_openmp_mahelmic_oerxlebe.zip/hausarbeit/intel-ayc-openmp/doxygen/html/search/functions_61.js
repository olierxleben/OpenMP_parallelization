var searchData=
[
  ['add_5fflight',['add_flight',['../class_travel.html#a3931da21a87c37cc604e3700c8557d1f',1,'Travel']]],
  ['add_5fplay_5fhard',['add_play_hard',['../class_solution.html#a1d10fedbb1083da04f5c72c17a25b914',1,'Solution']]]
];
