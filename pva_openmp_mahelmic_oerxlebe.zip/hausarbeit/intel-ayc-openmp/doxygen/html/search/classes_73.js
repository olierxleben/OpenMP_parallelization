var searchData=
[
  ['solution',['Solution',['../class_solution.html',1,'']]]
];
