var searchData=
[
  ['vacation_5ftime_5fmax',['vacation_time_max',['../struct_parameters.html#a36f22346c58dab71473c7920451f8100',1,'Parameters']]],
  ['vacation_5ftime_5fmin',['vacation_time_min',['../struct_parameters.html#a9149c9562e23842a0bfeea6cf3435119',1,'Parameters']]]
];
