var searchData=
[
  ['name',['name',['../class_location.html#a0ae46c7127ec349e484ed075c91ba258',1,'Location']]],
  ['nb_5fthreads',['nb_threads',['../struct_parameters.html#a930705020fe78a5e1a071aba1b85402d',1,'Parameters']]]
];
