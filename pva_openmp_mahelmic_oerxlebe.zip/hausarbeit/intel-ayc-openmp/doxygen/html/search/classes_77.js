var searchData=
[
  ['workhardtask',['WorkHardTask',['../classoma_1_1_work_hard_task.html',1,'oma']]]
];
