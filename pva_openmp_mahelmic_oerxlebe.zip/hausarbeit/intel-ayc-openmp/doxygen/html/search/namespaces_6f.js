var searchData=
[
  ['oma',['oma',['../namespaceoma.html',1,'']]]
];
